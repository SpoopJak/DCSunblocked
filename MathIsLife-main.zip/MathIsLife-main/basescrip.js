function MyRun() {
    open("https://spoopjak.github.io/MathIsLife/Home.html", "_self")
}